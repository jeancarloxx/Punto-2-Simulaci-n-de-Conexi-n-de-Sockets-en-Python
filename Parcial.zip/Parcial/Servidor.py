import socket
import threading

server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server.bind(('127.0.0.1', 8080)) 
server.listen(4)

print("Servidor conectado al puerto 8080")

clients = {}
lock = threading.Lock()
running = True 

def manejar_cliente(client, addr):
    print(f"Conexión aceptada desde {addr}")
    client.send("Ingrese su nombre de usuario: ".encode())
    username = client.recv(1024).decode().strip()
    
    with lock:
        clients[client] = username
    
    print(f"{username} ({addr}) se ha conectado.")
    client.send(f"Hola te conectaste correctamente, {username}!".encode())
    
    try:
        while running:
            mensaje = client.recv(1024).decode()
            if not mensaje:
                break
            print(f"Mensaje recibido de {username}: {mensaje}")
            
            respuesta = f"Mensaje recibido de {username}"
            client.send(respuesta.encode())
            
            with lock:
                for c in clients:
                    if c != client:
                        try:
                            c.send(f"{username}: {mensaje}".encode())
                        except:
                            pass
    except:
        pass
    finally:
        with lock:
            if client in clients:
                del clients[client]
        print(f"{username} ({addr}) se ha desconectado")
        client.close()

def aceptar_clientes():
    while running:
        try:
            client, addr = server.accept()
            thread = threading.Thread(target=manejar_cliente, args=(client, addr), daemon=True)
            thread.start()
        except:
            break

servidor = threading.Thread(target=aceptar_clientes, daemon=True)
servidor.start()

while True:
    comando = input("")
    if comando.lower() == "salir":
        print("Servidor deteniendose :)")
        running = False
        break

server.close()
print("Servidor detenido (:")

