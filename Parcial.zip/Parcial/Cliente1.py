import socket
import threading

client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client.connect(('127.0.0.1', 8080)) 


client.send("cliente 1".encode())  

def recibir_mensajes():
    while True:
        try:
            mensaje = client.recv(1024).decode()  # Solo recibe mensajes
            if not mensaje:
                break
            print(mensaje)  # Muestra mensajes recibidos
        except:
            print("Servidor desconectado :(")
            break


recibir = threading.Thread(target=recibir_mensajes, daemon=True)
recibir.start()

while True:
    mensaje = input("")
    if mensaje.lower() == "salir":
        break
    client.send(mensaje.encode())  
client.close()
